export const DATASETS = [
  'wits.summary-6h',
  'wits.summary-30m',
  'wits.summary-1m',
  'wits.summary-1ft'
]

